// 메뉴 선택 class
public class Menu {
	public static void mainMenu() {
		System.out.println("");
		System.out.println("-----------------------*********개인 일정 관리 프로그램*********------------------------");
		System.out.println("1. 일정 추가");
		System.out.println("2. 일정 검색");
		System.out.println("3. 일정 삭제");
		System.out.println("4. 일정 수정");
		System.out.println("5. 전체 일정 확인");
		System.out.println("6. 종료");
		System.out.println("---------------------------------------------------------------------------");
		System.out.print("원하시는 프로그램 번호를 입력해주세요 : ");
	}
	
	public static void searchMenu() {
		System.out.println("");
		System.out.println("--------*****검색 메뉴*****--------");
		System.out.println("1. 입력 날짜 이후 일정 검색");
		System.out.println("2. 입력 기간 사이 일정 검색");
		System.out.println("3. 키워드 검색");
		System.out.println("4. 우선순위별 검색");
		System.out.println("5. 카테고리별 검색");
		System.out.println("6. 검색 메뉴 종료");
		System.out.println("--------------------------------");
		System.out.print("원하시는 프로그램 번호를 입력해주세요 : ");
	}
	
	public static void deleteMenu() {
		System.out.println("");
		System.out.println("--------*****삭제 메뉴*****--------");
		System.out.println("1. 특정 날짜의 일정 삭제");
		System.out.println("2. 입력 기간 사이 일정 삭제");
		System.out.println("3. 키워드를 포함하는 일정 삭제");
		System.out.println("4. 특정 우선순위의 일정 삭제");
		System.out.println("5. 특정 카테고리의 일정 삭제");
		System.out.println("6. 삭제 메뉴 종료");
		System.out.println("--------------------------------");
		System.out.print("원하시는 프로그램 번호를 입력해주세요 : ");
	}
	
	public static void updateMenu() {
		System.out.println("");
		System.out.println("--------*****수정 메뉴*****--------");
		System.out.println("1. 특정 날짜의 일정 수정");
		System.out.println("2. 입력 기간 사이 일정 수정");
		System.out.println("3. 키워드를 포함하는 일정 수정");
		System.out.println("4. 특정 우선순위의 일정 수정");
		System.out.println("5. 특정 카테고리의 일정 수정");
		System.out.println("6. 수정 메뉴 종료");
		System.out.println("--------------------------------");
		System.out.print("원하시는 프로그램 번호를 입력해주세요 : ");
	}
}