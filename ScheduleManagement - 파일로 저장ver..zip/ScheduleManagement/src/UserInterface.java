// 사용자 인터페이스 class
import java.io.*;
import java.util.Scanner;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.InputMismatchException;

public class UserInterface{
	static Scanner scan = new Scanner(System.in);
	private static final String FILE_NAME = "schedules.txt";
	
	public static void main(String args[]) throws Exception{
		ScheduleManager manager = new ScheduleManager();
		Schedule newSchedule = null;
		
		// 파일 열기
		File file = openFile();
		// 파일 읽기 -> 자동으로
		try {
			manager.readSchedules(file);	
		}catch(IOException | ClassNotFoundException readEx) {
			System.out.println(readEx.getMessage());
		}

		while(true) {
			Menu.mainMenu(); // 초기 메뉴 제공
			int scheduleMenu = scan.nextInt(); // 사용자의 선택
			
			switch(scheduleMenu) {
			// 일정 추가
			case 1:
				while (true) {
					System.out.println("일정 정보를 입력하세요 (우선순위, 카데고리, 제목, 내용, 시작 시간, 마감 시간)");

					GregorianCalendar startDate, dueDate;
					String title, note, category = null;
					int priority = 1;
					try {
						System.out.print("우선순위(1~5) : ");
						priority = scan.nextInt();
						// 우선순위 범위 : 1 ~ 5
						if(priority < 1 || priority > 5) {
							throw new Exception("Wrong Priority");
						}
						
						System.out.println("카테고리 - U, P, F, S 중 택 1");
						System.out.print("학교('U'niversity), 개인('P'ersonal), 가족('F'amily), 공부('S'tudy)) : ");
						category = scan.next();
						// 주어진 문자 이외의 문자 입력시 에러 발생
						if(!"UPFS".contains(category)) {
							throw new Exception("Wrong Category");
						}
						
						scan.nextLine(); // 버퍼 내 \'n' 제거
					}catch(InputMismatchException e) {
						scan = new Scanner(System.in);
						System.out.println("잘못된 형식의 입력입니다. 다시 입력하세요.");
						continue;
					}catch(Exception e) {
						if(e.getMessage().equals("Wrong Priority")) {
							System.out.println("우선순위는 1에서 5 사이의 값으로 입력하세요.");
						}
						if(e.getMessage().equals("Wrong Category")) {
							System.out.println("주어진 보기에서 선택하여 입력하세요.(U, P, F, S 중 택 1)");
						}
						continue; // 에러 발생 시 처음부터 다시 입력
					}
					try {
						System.out.print("일정 제목 : ");
						title = scan.nextLine();
						System.out.print("일정 내용 : ");
						note = scan.nextLine();
						System.out.println("시작 시간");
						startDate = inputDateTime();
						System.out.println("마감 시간");
						dueDate = inputDateTime();
						
						// 시작 시간과 마감 시간이 반대로 입력된 경우 -> 두 시간을 바꿔서 저장
						if(startDate.after(dueDate)) {
							GregorianCalendar time;
							time = startDate;
							startDate = dueDate;
							dueDate = time;
						}
						
						newSchedule = new Schedule(priority, category.charAt(0), title, note, startDate, dueDate);
						manager.addSchedule(newSchedule);
						break;
						
					}catch(InputMismatchException e) {
						scan = new Scanner(System.in);
						System.out.println("잘못된 형식의 입력입니다. 다시 입력하세요.");
					}catch(Exception e) {
						if(e.getMessage().equals("Exist")) {
							System.out.print("동일한 날짜에 일정이 존재합니다. 계속해서 일정을 추가하시겠습니까? Y : N > ");
							char check = scan.nextLine().charAt(0);
							// Y 선택 -> 일정 추가
							if((check == 'Y') || (check == 'y')) {
								manager.addSameSchedule(newSchedule);
								System.out.println("일정을 추가했습니다.");
								break;
							}
							// N 선택 -> 처음부터 일정 입력
							if((check == 'N') || (check == 'n')) {
								System.out.println("추가할 일정을 다시 입력해주세요.");
								continue;
							}
						}
						if(e.getMessage().equals("Out of Range")) {
							System.out.println("일정 목록이 가득 찼습니다. 완료된 일정 삭제 후 다시 시도하세요.");
							break;
						}
					}
					break;
				}
				saveToFile(manager, file);
				break;
			// 일정 검색
			case 2:
				while(true) {
					Menu.searchMenu();
					int searchMenu = scan.nextInt(); // 검색 메뉴에서의 사용자의 선택
					Schedule searchResult[]; // 검색 결과
					
					switch(searchMenu) {
					// 입력 날짜 이후 일정 검색
					case 1:
						System.out.println("기준 날짜 이후 일정 검색 - 기준 날짜를 입력하세요.");
						searchResult = manager.search(inputSearchTime());
						// 검색된 일정이 없는 경우
						try {
							if(searchResult == null) {
								throw new Exception("Empty");
							}
							printSchedule(searchResult);
						}catch(Exception e) {
							if(e.getMessage().equals("Empty")) {
								System.out.println("해당되는 일정이 존재하지 않습니다.");	
								break;
							}
						}
						break;
					// 입력 기간 사이 일정 검색
					case 2:
						System.out.println("기간 사이의 일정 검색 - 시작 날짜와 종료 날짜를 차례로 입력하세요.");
						GregorianCalendar from, end;
						System.out.println("시작 날짜");
						from = inputSearchTime();
						System.out.println("종료 날짜");
						end = inputSearchTime();
						// 종료 날짜의 경우 일을 입력하지 않은 경우 해당 월을 마지막 일로 설정되어야 함
						int endMonth = end.get(Calendar.MONTH);
						int endDate = end.get(Calendar.DATE);
						if(endMonth != -1 && endDate == 1) {
							endDate = end.getActualMaximum(Calendar.DAY_OF_MONTH);
						}
						end = new GregorianCalendar(end.get(Calendar.YEAR), endMonth, endDate);
						searchResult = manager.search(from, end);
						// 검색된 일정이 없는 경우
						try {
							if(searchResult == null) {
								throw new Exception("Empty");
							}
							printSchedule(searchResult);
						}catch(Exception e) {
							if(e.getMessage().equals("Empty")) {
								System.out.println("해당되는 일정이 존재하지 않습니다.");	
							}
						}
						break;
					// 키워드 검색
					case 3:
						scan.nextLine(); // 버퍼에 남아있는 '\n' 제거
						
						try {
							System.out.print("키워드 검색 - 키워드를 입력하세요 : ");
							String keyword = scan.nextLine();
							searchResult = manager.search(keyword);
							
							// 검색된 일정이 없는 경우
							if(searchResult == null) {
								throw new Exception("Empty");
							}
							printSchedule(searchResult);
						}catch(InputMismatchException e) {
							scan = new Scanner(System.in);
							System.out.println("잘못된 형식의 입력입니다. 다시 입력하세요.");
						}
						catch(Exception e) {
							if(e.getMessage().equals("Empty")) {
								System.out.println("해당되는 일정이 존재하지 않습니다.");
							}
						}
						break;
					// 우선순위 검색
					case 4:
						scan.nextLine(); // 버퍼에 남아있는 '\n' 제거
						try {
							System.out.print("우선 순위 검색 - 찾고자 하는 우선순위를 입력하세요(1~5) : ");
							int priority = scan.nextInt();
							if(priority < 1 || priority > 5) {
								throw new Exception("wrong Priority");
							}
							
							searchResult = manager.search(priority);
							// 검색된 일정이 없는 경우
							if(searchResult == null) {
								throw new Exception("Empty");
							}
							printSchedule(searchResult);
						}catch(InputMismatchException e) {
							scan = new Scanner(System.in);
							System.out.println("잘못된 형식의 입력입니다. 다시 입력하세요.");
						}catch(Exception e) {
							if(e.getMessage().equals("Wrong Priority")) {
								System.out.println("우선순위는 1~5 사이에 존재합니다. 다시 입력하세요.");
								break;
							}
							if(e.getMessage().equals("Empty")) {
								System.out.println("해당되는 일정이 존재하지 않습니다.");
								break;
							}
						}
						break;
					// 카테고리 검색
					case 5:
						scan.nextLine(); // 버퍼에 남아있는 '\n' 제거
						try {
							System.out.print("카테고리 검색 - 찾고자 하는 카테고리를 입력하세요(U, P, F, S) : ");
							String category = scan.nextLine();
							if(!"UPFS".contains(category)) {
								throw new Exception("Wrong Category");
							}
							searchResult = manager.search(category.charAt(0));
							// 검색된 일정이 없는 경우
							if(searchResult == null) {
								throw new Exception("Empty");
							}
							printSchedule(searchResult);
						}catch(InputMismatchException e) {
							scan = new Scanner(System.in);
							System.out.println("잘못된 형식의 입력입니다. 다시 입력하세요.");
						}catch(Exception e) {
							if(e.getMessage().equals("Wrong Category")) {
								System.out.println("카테고리는 U, P, F, S 중 하나를 입력해야 합니다. 다시 입력하세요.");
								break;
							}
							if(e.getMessage().equals("Empty")) {
								System.out.println("해당되는 일정이 존재하지 않습니다.");
							}
						}
					break;
					// 검색 메뉴 종료
					case 6:
						System.out.println("검색 메뉴를 종료합니다.");
						break;
						
					default:
						// 숫자를 잘못 입력한 경우
						System.out.println("다시 입력하세요 "); 
						break;		
					} // 검색 메뉴 switch 문 종료
					
					// 6번 선택 시 검색 메뉴 종료
					if (searchMenu == 6) {
						break;
					}
				}

				break; // 메인 메뉴 case 2 종료
		
			// 일정 삭제
			case 3:
				while(true) {
					Menu.deleteMenu();
					int deleteMenu = scan.nextInt(); // 검색 메뉴에서의 사용자의 선택
					Schedule indexSchedule[];
					int[] indexes; // searchIndex 반환값 받음
					int num = 0; // indexSchedule의 인덱스
					
					switch(deleteMenu){
					// 특정 날짜의 일정 삭제
					case 1:
						System.out.println("특정 날짜의 일정 삭제 - 기준 날짜를 입력하세요.");
						GregorianCalendar date = inputSearchTime();
						indexes = manager.searchIndex(date);
						
						try {
							// 해당 일정이 없는 경우
							if(indexes.length == 0) {
								throw new Exception("Empty");
							}
							
							indexSchedule = new Schedule[indexes.length];
							// 인덱스 리스트(searchIndex 함수로 반환됨) 내 인덱스가 존재하는 일정만 저장된 새로운 리스트
							for(int i = 0; i < indexes.length ; i++) {
								indexSchedule[num++] = manager.getScheduleList()[indexes[i]];
							}
							System.out.println("해당 날짜에 진행 중인 일정은 다음과 같습니다.");
							printSchedule(indexSchedule);

						}catch(Exception e) {
							if(e.getMessage().equals("Empty")) {
								System.out.println("해당되는 일정이 존재하지 않습니다.");
								break;
							}
						}
						// 삭제할 일정 번호 입력받에 삭제 진행
						deleteSchedule(manager, num);
						break; // 특정 날짜의 일정 삭제 메뉴 종료
					// 기간 사이 일정 삭제
					case 2:
						System.out.println("기간 사이 일정 삭제 - 시작 날짜와 종료 날짜를 차례로 입력하세요.");
						GregorianCalendar from, end;
						System.out.println("시작 날짜");
						from = inputSearchTime();
						System.out.println("종료 날짜");
						end = inputSearchTime();
						// 종료 날짜의 경우 일을 입력하지 않은 경우 해당 월을 마지막 일로 설정되어야 함
						int endMonth = end.get(Calendar.MONTH);
						int endDate = end.get(Calendar.DATE);
						if(endMonth != -1 && endDate == 1) {
							endDate = end.getActualMaximum(Calendar.DAY_OF_MONTH);
						}
						end = new GregorianCalendar(end.get(Calendar.YEAR), endMonth, endDate);
						indexes = manager.searchIndex(from, end);

						try {
							// 해당 일정이 없는 경우
							if(indexes.length == 0) {
								throw new Exception("Empty");
							}
							
							indexSchedule = new Schedule[indexes.length];
							// 인덱스 리스트(searchIndex 함수로 반환됨) 내 인덱스가 존재하는 일정만 저장된 새로운 리스트
							for(int i = 0; i < indexes.length ; i++) {
								indexSchedule[num++] = manager.getScheduleList()[indexes[i]];
							}
							System.out.println("해당 기간 사이에 진행 중인 일정은 다음과 같습니다.");
							printSchedule(indexSchedule);
						
						}catch(Exception e) {
							if(e.getMessage().equals("Empty")) {
								System.out.println("해당되는 일정이 존재하지 않습니다.");
								break;
							}
						}
						// 삭제할 일정 번호 입력받에 삭제 진행
						deleteSchedule(manager, num);	
						break; // 기간 사이 일정 삭제 메뉴 종료
					// 키워드를 포함하는 일정 삭제
					case 3:
						scan.nextLine(); // 버퍼 비우기
						try {
							System.out.print("키워드를 포함하는 일정 삭제 - 키워드를 입력하세요 : ");
							String keyword = scan.nextLine();
							indexes = manager.searchIndex(keyword);

							// 해당 일정이 없는 경우
							if(indexes.length == 0) {
								throw new Exception("Empty");
							}
							
							indexSchedule = new Schedule[indexes.length];
							// 인덱스 리스트(searchIndex 함수로 반환됨) 내 인덱스가 존재하는 일정만 저장된 새로운 리스트
							for(int i = 0; i < indexes.length ; i++) {
								indexSchedule[num++] = manager.getScheduleList()[indexes[i]];
							}
							System.out.println("해당 키워드를 포함하는 일정은 다음과 같습니다.");
							printSchedule(indexSchedule);

						}catch(InputMismatchException e) {
							scan = new Scanner(System.in);
							System.out.println("잘못된 형식의 입력입니다. 다시 입력하세요.");
						}catch(Exception e) {
							if(e.getMessage().equals("Empty")) {
								System.out.println("해당되는 일정이 존재하지 않습니다.");
								break;
							}
						}
						// 삭제할 일정 번호 입력받에 삭제 진행
						deleteSchedule(manager, num);
						break; // 키워드 포함 일정 삭제 종료
					// 특정 우선순위의 일정 삭제
					case 4:
						scan.nextLine(); // 버퍼 비우기
						try {
							System.out.print("특정 우선순위의 일정 삭제 - 우선순위를 입력하세요(1~5) : ");
							int priority = scan.nextInt();
							if(priority < 1 || priority > 5) {
								throw new Exception("Wrong Priority");
							}
							indexes = manager.searchIndex(priority);
							
							// 해당 일정이 없는 경우
							if(indexes.length == 0) {
								throw new Exception("Empty");
							}
							
							indexSchedule = new Schedule[indexes.length];
							// 인덱스 리스트(searchIndex 함수로 반환됨) 내 인덱스가 존재하는 일정만 저장된 새로운 리스트
							for(int i = 0; i < indexes.length ; i++) {
								indexSchedule[num++] = manager.getScheduleList()[indexes[i]];
							}
							System.out.println("해당 우선순위의 일정은 다음과 같습니다.");
							printSchedule(indexSchedule);

		
						}catch(InputMismatchException e) {
							scan = new Scanner(System.in);
							System.out.println("잘못된 형식의 입력입니다. 다시 입력하세요.");
							break;
						}catch(Exception e) {
							if(e.getMessage().equals("Wrong Priority")) {
								System.out.println("우선순위는 1~5 사이에 존재합니다. 다시 입력하세요.");
								break;
							}
							if(e.getMessage().equals("Empty")) {
								System.out.println("해당되는 일정이 존재하지 않습니다.");
								break;
							}
						}
						// 삭제할 일정 번호 입력받에 삭제 진행
						deleteSchedule(manager, num);
						break; // 특정 우선순위의 일정 삭제
					// 특정 카테고리의 일정 삭제
					case 5:
						scan.nextLine(); // 버퍼 비우기
						try {
							System.out.print("특정 카테고리의 일정 삭제 - 카테고리를 입력하세요(U, P, F, S) : ");
							String category = scan.nextLine();
							if(!"UPFS".contains(category)) {
								throw new Exception("Wrong Category");
							}
							indexes = manager.searchIndex(category.charAt(0));
							
							// 해당 일정이 없는 경우
							if(indexes.length == 0) {
								throw new Exception("Empty");
							}
							
							indexSchedule = new Schedule[indexes.length];
							// 인덱스 리스트(searchIndex 함수로 반환됨) 내 인덱스가 존재하는 일정만 저장된 새로운 리스트
							for(int i = 0; i < indexes.length ; i++) {
								indexSchedule[num++] = manager.getScheduleList()[indexes[i]];
							}
							System.out.println("해당 카테고리의 일정은 다음과 같습니다.");
							printSchedule(indexSchedule);
							
						}catch(InputMismatchException e) {
							scan = new Scanner(System.in);
							System.out.println("잘못된 형식의 입력입니다. 다시 입력하세요.");
						}catch(Exception e) {
							if(e.getMessage().equals("Wrong Category")) {
								System.out.println("카테고리는 U, P, F, S 중 하나를 입력해야 합니다. 다시 입력하세요.");
								break;
							}
							if(e.getMessage().equals("Empty")) {
								System.out.println("해당되는 일정이 존재하지 않습니다.");
								break;
							}
						}
						// 삭제할 일정 번호 입력받에 삭제 진행
						deleteSchedule(manager, num);
						break; // 특정 우선순위의 일정 삭제
					// 삭제 메뉴 종료
					case 6:
						System.out.println("삭제 메뉴를 종료합니다.");
						break;
						
					default:
						// 숫자를 잘못 입력한 경우
						System.out.println("다시 입력하세요 "); 
						break;		
					} // 검색 메뉴 switch 문 종료
					
					// 6번 선택 시 검색 메뉴 종료
					if (deleteMenu == 6) {
						break;
					}
				}
				// 파일에 저장
				saveToFile(manager, file);
				break; // 일정 삭제 케이스 break
			// 일정 수정
			case 4:
				Schedule indexSchedule[];
				int[] indexes = new int[manager.getScheduleNum()]; // searchIndex 반환값 받음
				int num = 0; // indexSchedule의 인덱스
				
				while(true) {
					Menu.updateMenu();
					int updateMenu = scan.nextInt(); // 사용자의 선택

					switch(updateMenu) {
					// 특정 날짜의 일정 수정
					case 1:
						System.out.println("특정 날짜의 일정 수정 - 기준 날짜를 입력하세요.");
						GregorianCalendar date = inputSearchTime();
						indexes = manager.searchIndex(date);

						try {
							// 해당 일정이 없는 경우
							if(indexes.length == 0) {
								throw new Exception("Empty");
							}
							
							indexSchedule = new Schedule[indexes.length];
							// 인덱스 리스트(searchIndex 함수로 반환됨) 내 인덱스가 존재하는 일정만 저장된 새로운 리스트
							for(int i = 0; i < indexes.length ; i++) {
								indexSchedule[num++] = manager.getScheduleList()[indexes[i]];
							}
							System.out.println("해당 날짜에 진행 중인 일정은 다음과 같습니다.");
							printSchedule(indexSchedule);
						}catch(Exception e) {
							if(e.getMessage().equals("Empty")) {
								System.out.println("해당되는 일정이 존재하지 않습니다.");
								break;
							}
						}
						// 수정할 일정 번호 입력받아 수정 진행
						try {
							System.out.print("몇 번째 일정을 수정하시겠습니까?");
							updateMenu = scan.nextInt();
							// 인덱스 범위 불일치시 예외 발생
							if(updateMenu < 1 || updateMenu > indexes.length) {
								throw new Exception("Out of Range");
							}
						}catch(Exception e) {
							if(e.getMessage().equals("Out of Range")) {
								System.out.println("위 일정 목록의 개수 내에서 입력하세요.");
								break;
							}
						}
						updateSchedule(manager, updateMenu - 1);
						break;
					// 특정 기간의 일정 수정
					case 2:
						System.out.println("기간 사이 일정 수정 - 시작 날짜와 종료 날짜를 차례로 입력하세요.");
						GregorianCalendar from, end;
						System.out.println("시작 날짜");
						from = inputSearchTime();
						System.out.println("종료 날짜");
						end = inputSearchTime();
						// 종료 날짜의 경우 일을 입력하지 않은 경우 해당 월을 마지막 일로 설정되어야 함
						int endMonth = end.get(Calendar.MONTH);
						int endDate = end.get(Calendar.DATE);
						if(endMonth != -1 && endDate == 1) {
							endDate = end.getActualMaximum(Calendar.DAY_OF_MONTH);
						}
						end = new GregorianCalendar(end.get(Calendar.YEAR), endMonth, endDate);
						indexes = manager.searchIndex(from, end);

						try {
							// 해당 일정이 없는 경우
							if(indexes.length == 0) {
								throw new Exception("Empty");
							}
							
							indexSchedule = new Schedule[indexes.length];
							// 인덱스 리스트(searchIndex 함수로 반환됨) 내 인덱스가 존재하는 일정만 저장된 새로운 리스트
							for(int i = 0; i < indexes.length ; i++) {
								indexSchedule[num++] = manager.getScheduleList()[indexes[i]];
							}
							System.out.println("해당 기간 사이에 진행 중인 일정은 다음과 같습니다.");
							printSchedule(indexSchedule);
						}catch(Exception e) {
							if(e.getMessage().equals("Empty")) {
								System.out.println("해당되는 일정이 존재하지 않습니다.");
								break;
							}
							break;
						}
						// 수정할 일정 번호 입력받아 수정 진행
						try {
							System.out.print("몇 번째 일정을 수정하시겠습니까?");
							updateMenu = scan.nextInt();
							// 인덱스 범위 불일치시 예외 발생
							if(updateMenu < 1 || updateMenu > indexes.length) {
								throw new Exception("Out of Range");
							}
						}catch(Exception e) {
							if(e.getMessage().equals("Out of Range")) {
								System.out.println("위 일정 목록의 개수 내에서 입력하세요.");
								break;
							}
						}
						updateSchedule(manager, updateMenu - 1);
						break;
					// 특정 키워드의 일정 수정
					case 3:
						scan.nextLine(); // 버퍼 비우기
						try {
							System.out.print("키워드를 포함하는 일정 삭제 - 키워드를 입력하세요 : ");
							String keyword = scan.nextLine();
							indexes = manager.searchIndex(keyword);

							// 해당 일정이 없는 경우
							if(indexes.length == 0) {
								throw new Exception("Empty");
							}
							
							indexSchedule = new Schedule[indexes.length];
							// 인덱스 리스트(searchIndex 함수로 반환됨) 내 인덱스가 존재하는 일정만 저장된 새로운 리스트
							for(int i = 0; i < indexes.length ; i++) {
								indexSchedule[num++] = manager.getScheduleList()[indexes[i]];
							}
							System.out.println("해당 키워드를 포함하는 일정은 다음과 같습니다.");
							printSchedule(indexSchedule);
			
						}catch(InputMismatchException e) {
							scan = new Scanner(System.in);
							System.out.println("잘못된 형식의 입력입니다. 다시 입력하세요.");
						}catch(Exception e) {
							if(e.getMessage().equals("Empty")) {
								System.out.println("해당되는 일정이 존재하지 않습니다.");
								break;
							}
							break;
						}		
						// 수정할 일정 번호 입력받아 수정 진행
						try {
							System.out.print("몇 번째 일정을 수정하시겠습니까?");
							updateMenu = scan.nextInt();
							// 인덱스 범위 불일치시 예외 발생
							if(updateMenu < 1 || updateMenu > indexes.length) {
								throw new Exception("Out of Range");
							}	
						}catch(Exception e) {
							if(e.getMessage().equals("Out of Range")) {
								System.out.println("위 일정 목록의 개수 내에서 입력하세요.");
								break;
							}
						}
						updateSchedule(manager, updateMenu - 1);
						break;
					// 특정 우선순위의 일정 수정
					case 4:
						scan.nextLine();
						try {
							System.out.print("특정 우선순위의 일정 삭제 - 우선순위를 입력하세요(1~5) : ");
							int priority = scan.nextInt();
							if(priority < 1 || priority > 5) {
								throw new Exception("Wrong Priority");
							}
							indexes = manager.searchIndex(priority);
							
							// 해당 일정이 없는 경우
							if(indexes.length == 0) {
								throw new Exception("Empty");
							}
							
							indexSchedule = new Schedule[indexes.length];
							// 인덱스 리스트(searchIndex 함수로 반환됨) 내 인덱스가 존재하는 일정만 저장된 새로운 리스트
							for(int i = 0; i < indexes.length ; i++) {
								indexSchedule[num++] = manager.getScheduleList()[indexes[i]];
							}
							System.out.println("해당 우선순위의 일정은 다음과 같습니다.");
							printSchedule(indexSchedule);
		
						}catch(InputMismatchException e) {
							scan = new Scanner(System.in);
							System.out.println("잘못된 형식의 입력입니다. 다시 입력하세요.");
							break;
						}catch(Exception e) {
							if(e.getMessage().equals("Wrong Priority")) {
								System.out.println("우선순위는 1~5 사이에 존재합니다. 다시 입력하세요.");
								break;
							}
							if(e.getMessage().equals("Empty")) {
								System.out.println("해당되는 일정이 존재하지 않습니다.");
								break;
							}
						}
						// 수정할 일정 번호 입력받아 수정 진행
						try {
							System.out.print("몇 번째 일정을 수정하시겠습니까?");
							updateMenu = scan.nextInt();
							// 인덱스 범위 불일치시 예외 발생
							if(updateMenu < 1 || updateMenu > indexes.length) {
								throw new Exception("Out of Range");
							}
						}catch(Exception e) {
							if(e.getMessage().equals("Out of Range")) {
								System.out.println("위 일정 목록의 개수 내에서 입력하세요.");
								break;
							}
						}
						updateSchedule(manager, updateMenu - 1);
						break;
					// 특정 카테고리의 일정 수정
					case 5:
						scan.nextLine(); // 버퍼 비우기
						try {
							System.out.print("특정 카테고리의 일정 삭제 - 카테고리를 입력하세요(U, P, F, S) : ");
							String category = scan.nextLine();
							if(!"UPFS".contains(category)) {
								throw new Exception("Wrong Category");
							}
							indexes = manager.searchIndex(category.charAt(0));
							
							// 해당 일정이 없는 경우
							if(indexes.length == 0) {
								throw new Exception("Empty");
							}	
							indexSchedule = new Schedule[indexes.length];
							// 인덱스 리스트(searchIndex 함수로 반환됨) 내 인덱스가 존재하는 일정만 저장된 새로운 리스트
							for(int i = 0; i < indexes.length ; i++) {
								indexSchedule[num++] = manager.getScheduleList()[indexes[i]];
							}
							System.out.println("해당 카테고리의 일정은 다음과 같습니다.");
							printSchedule(indexSchedule);
							
						}catch(InputMismatchException e) {
							scan = new Scanner(System.in);
							System.out.println("잘못된 형식의 입력입니다. 다시 입력하세요.");
						}catch(Exception e) {
							if(e.getMessage().equals("Wrong Category")) {
								System.out.println("카테고리는 U, P, F, S 중 하나를 입력해야 합니다. 다시 입력하세요.");
								break;
							}
							if(e.getMessage().equals("Empty")) {
								System.out.println("해당되는 일정이 존재하지 않습니다.");
								break;
							}
						}
						// 수정할 일정 번호 입력받아 수정 진행
						try {
							System.out.print("몇 번째 일정을 수정하시겠습니까?");
							updateMenu = scan.nextInt();
							// 인덱스 범위 불일치시 예외 발생
							if(updateMenu < 1 || updateMenu > indexes.length) {
								throw new Exception("Out of Range");
							}
						}catch(Exception e) {
							if(e.getMessage().equals("Out of Range")) {
								System.out.println("위 일정 목록의 개수 내에서 입력하세요.");
								break;
							}
						}
						updateSchedule(manager, updateMenu - 1);
						break;
					// 수정 메뉴 종료
					case 6:
						System.out.println("수정 메뉴를 종료합니다.");
						break;
						
					default:
						// 숫자를 잘못 입력한 경우
						System.out.println("다시 입력하세요 "); 
						break;		
					} // 검색 메뉴 switch 문 종료
					
					// 6번 선택 시 검색 메뉴 종료
					if (updateMenu == 6) {
						break;
					}
				}
				// 종료 전 파일에 내용 저장
				saveToFile(manager, file);
				break;
			// 전체 일정 확인
			case 5:
				Schedule allSchedule[] = manager.getScheduleList();
				if(allSchedule == null || allSchedule.length == 0) {
					System.out.println("저장된 일정이 없습니다.");
					break;
				}
				System.out.println("현재 남아있는 일정입니다.");
				printSchedule(allSchedule);
				break;
			// 프로그램 종료
			case 6:
				// 종료 전 파일에 내용 저장
				saveToFile(manager, file);
				System.out.println("일정 관리 프로그램을 종료합니다.");
				break;
				
			default:
				// 숫자를 잘못 입력한 경우
				System.out.println("다시 입력하세요 "); 
				break;	
			}// switch 문 종료
			
			if(scheduleMenu == 6) {
				return;
			}
		}// 메뉴 선택 while 문 종료
	}// main 함수 종료
	
	// 파일 열기
	private static File openFile() {
		File file = new File(FILE_NAME);
		try {
			if(!file.exists()) {
				file.createNewFile(); // 파일이 없을 경우 새로 생성
			}
		}catch(IOException ioe) {
			System.out.println(ioe.getMessage());
			System.out.println("파일 생성 오류");
		}
		return file;
	}
	// 파일 저장
	private static void saveToFile(ScheduleManager manager, File file) {
		while(true) {
			try {
				scan.nextLine();
				// 종료 전 파일에 내용 저장 -> 사용자의 선택에 따라서 결정
				System.out.print("현재 내용을 파일에 저장하시겠습니까?(Y or N) : ");
				String save = scan.nextLine();
				if('Y' == save.charAt(0) || 'y' == save.charAt(0)) {
					manager.writeSchedules(file);
					System.out.println("저장을 완료했습니다.");
					break;
				}
				else if('N' == save.charAt(0) || 'n' == save.charAt(0)) {
					System.out.println("저장하지 않았습니다.");
					break;
				}
				else {
					throw new Exception("Wrong Answer");
				}
			}catch(IOException ioe) {
				System.out.println(ioe.getMessage());
			}catch(Exception e) {
				if(e.getMessage().equals("Wrong Answer")) {
					System.out.println(e.getMessage() + " -> 다시 입력해주세요.");
				}
			}		
		}
	}
	
	// 시간 입력 함수 - 일정 추가 시 호출
	private static GregorianCalendar inputDateTime() {
		int year, month, date, hour, min;
		while(true) {
			// 연도 입력
			try {
				System.out.print("연도(Year): ");
		        year = scan.nextInt();
		        if(year < 1) {
		        	throw new Exception("Minus Year");
		        }
		        
		        System.out.print("월(Month): ");
		        month = scan.nextInt() - 1;
		        if(month < 0 || month > 11) { // 월이 1~12 사이 숫자가 아닐 경우 에러 발생
		        	throw new Exception("Wrong Month");
		        }

		        System.out.print("일(Date): ");
		        date = scan.nextInt();
		        if(date < 1 || date > 31) { // 일이 1~31 사이 숫자가 아닐 경우 에러 발생
		        	throw new Exception("Wrong Date");
		        }
		        scan.nextLine(); // 버퍼 제거
		        // 시간, 분 입력
		        System.out.print("시간(Hour : 0~23)(입력하지 않을 경우 0으로 설정됨): ");
		        String time = scan.nextLine();
		        hour = time.isEmpty()? 0 : Integer.parseInt(time);
		        // 음수이거나 범위 초과일 경우 에러 발생
		        if(hour < 0 || hour > 23) {
		        	throw new Exception("Wrong Hour");
		        }
		    	System.out.print("분(Min)(입력하지 않을 경우 0으로 설정됨): ");
		        String minute = scan.nextLine();
		        min = minute.isEmpty()? 0 : Integer.parseInt(minute);
	        	// 음수이거나 범위 초과일 경우 에러 발생
	        	if(min < 0 || min > 59) {
		        	throw new Exception("Wrong Min");
		        }
	        	
		        break;
		    }catch(NumberFormatException e) {
		    	System.out.println("숫자를 입력하세요.");
		    }
			catch(Exception e) {
		    	System.out.println(e.getMessage());
		    } 
		}// while 문 종료
        return new GregorianCalendar(year, month, date, hour, min);
	}// 시간 입력 함수 종료
	
	// 시간 입력 함수 - 일정 검색 시 호출(연도만 필수, 시간 및 분은 입력받지 않음)
	private static GregorianCalendar inputSearchTime() {
		int year, month = -1, date = -1; // 월과 일 값은 입력받지 않을 경우를 기준으로 초기화
		while(true) {
			// 연도 입력
			try {
				System.out.print("연도(Year): ");
		        year = scan.nextInt();
		        if(year < 1) {
		        	throw new Exception("Minus Year");
		        }
		        scan.nextLine(); // 버퍼 제거
		        
		        System.out.print("월(Month, 입력하지 않을 경우 해당 연도 1월 1일 기준): ");
		        String inputMonth = scan.nextLine();
		        if(!inputMonth.isEmpty()) {
	                month = Integer.parseInt(inputMonth);
	                if(month < 1 || month > 12) {
	                    throw new Exception("Wrong Month");
	                }
	                // 월이 입력된 경우에만 일 입력
	                System.out.print("일(Date, 입력하지 않을 경우 해당 월의 1일(마지막일) 기준): ");
			        String inputDate = scan.nextLine();
			        if(!inputDate.isEmpty()) {
		                date = Integer.parseInt(inputDate);
		                if(date < 1 || date > 31) {
		                    throw new Exception("Wrong Date");
		                }
		            }
	            }
		        
		        // 연도만 입력한 경우 : 해당 연도의 1월 1일로 설정
		        if(month == -1 && date == -1) {
		        	month = Calendar.JANUARY;
		        	date = 1;
		        	return new GregorianCalendar(year, month, date);
		        }
		        // 연도 + 월 입력한 경우
		        else if(month != -1 && date == -1) {
		        	date = 1;
		        	return new GregorianCalendar(year, month - 1, date);
		        }
		        // 모두 입력한 경우
		        else {
		        	return new GregorianCalendar(year, month - 1, date);
		        }
		        
		    }catch(NumberFormatException e) {
		    	System.out.println("숫자를 입력하세요.");
		    }
			catch(Exception e) {
		    	System.out.println(e.getMessage());
		    } 
		}// while 문 종료
	}// 시간 입력 함수 종료
	
	// 일정 출력 형식 지정 함수
	private static void printSchedule(Schedule s[]) {
		System.out.println("우선순위\t카테고리\t이름 및 내용\t\t시작 시간\t\t마감 시간");
		for(int i = 0; i < s.length; i++) {
			if(s[i] != null) {
				int priority = s[i].getPriority();
				char category = s[i].getCategory();
				String title = s[i].getTitle();
				String note = s[i].getNote();
				GregorianCalendar startDate = s[i].getStartDate();
				GregorianCalendar dueDate = s[i].getDueDate();
				
				System.out.print(priority + "\t" + category + "\t" + title + " - " + note);
				System.out.print("\t" + startDate.get(Calendar.YEAR) + '.' + (startDate.get(Calendar.MONTH) + 1) + '.' + startDate.get(Calendar.DATE) + ' ' + startDate.get(Calendar.HOUR_OF_DAY) + ':' + startDate.get(Calendar.MINUTE));
				System.out.println("\t" + dueDate.get(Calendar.YEAR) + '.' + (dueDate.get(Calendar.MONTH) + 1) + '.' + dueDate.get(Calendar.DATE) + ' ' + dueDate.get(Calendar.HOUR_OF_DAY) + ':' + dueDate.get(Calendar.MINUTE));
			}
		}
	}
	
	// 삭제 형식 함수
	private static void deleteSchedule(ScheduleManager manager, int num) {
		try {
			System.out.print("삭제하고자 하는 일정은 몇 번째 일정입니까?");
			int deleteNum = scan.nextInt(); // 삭제하고자 하는 일정의 번호
			if(deleteNum > num || deleteNum < 1) {
				throw new Exception("Wrong Num");
			}
			manager.deleteSchedule(deleteNum - 1); // 리스트의 인덱스는 0부터 시작, 사용자는 1부터로 인식
			System.out.println("일정을 삭제했습니다.");
			
		}catch(InputMismatchException e) {
			System.out.println("잘못된 형식의 입력입니다. 다시 입력하세요.");
		}catch(Exception e) {
			if(e.getMessage().equals("Wrong Num")) {
				System.out.println("위 일정 목록의 개수 내에서 입력하세요.");
			}
		}
	}
	
	// 수정 형식 함수
	private static void updateSchedule(ScheduleManager manager, int index) {
		Schedule updateSchedule;
		Schedule originalSchedule = manager.getScheduleList()[index];
		GregorianCalendar sDate = originalSchedule.getStartDate();
		GregorianCalendar dDate = originalSchedule.getDueDate();
		
		int newPriority = 0;
		char newCategory = 0;
		String newTitle = null, newNote = null;
		GregorianCalendar newSDate = null, newDDate = null;

		try {
			System.out.println("일정 수정 - 입력하지 않은 내용은 이전 내용과 동일하게 적용됩니다.");
			System.out.print("우선순위(1~5) : ");
			String newPri = scan.next();
			newPriority = newPri.isEmpty()? originalSchedule.getPriority() : Integer.parseInt(newPri);
			
			scan.nextLine();
			System.out.print("카테고리(U, P, F, S) : ");
			String newCat = scan.nextLine();
			newCategory = newCat.isEmpty()? originalSchedule.getCategory() : newCat.charAt(0);
			
			System.out.print("일정 제목 : ");
			String newT = scan.nextLine();
			newTitle = newT.isEmpty()? originalSchedule.getTitle() : newT;
			
			System.out.print("일정 내용 : ");
			String newN = scan.nextLine();
			newNote = newN.isEmpty()? originalSchedule.getNote() : newN;
		}catch(InputMismatchException e) {
			System.out.println("잘못된 형식의 입력입니다. 다시 입력하세요.");
		}
		try {
			System.out.println("시작 시간");
			System.out.print("연도(Year): ");
			String newY = scan.nextLine();
			if((!newY.isEmpty()) && (Integer.parseInt(newY) < 1)) { // 입력한 값이 음수일 경우 에러 발생
				throw new Exception("Wrong Year");
			}
			int newYear = newY.isEmpty()? sDate.get(Calendar.YEAR) : Integer.parseInt(newY);
			System.out.print("월(Month): ");
			String newM = scan.nextLine();
			if((!newM.isEmpty()) && (Integer.parseInt(newM) < 1 || Integer.parseInt(newM) > 12)) {
				throw new Exception("Wrong Month");
			}
			int newMonth= newM.isEmpty()? sDate.get(Calendar.MONTH) : Integer.parseInt(newM) - 1;
			System.out.print("일(Date): ");
			String newD = scan.nextLine();
			if((!newD.isEmpty()) && (Integer.parseInt(newD) < 1)) {
				throw new Exception("Wrong Date");
			}
			int newDate = newD.isEmpty()? sDate.get(Calendar.DATE) : Integer.parseInt(newD);
			System.out.print("시간(Hour): ");
			String newH = scan.nextLine();
			if((!newH.isEmpty()) && (Integer.parseInt(newH) < 1 || Integer.parseInt(newH) > 23)) {
				throw new Exception("Wrong Hour");
			}
			int newHour = newH.isEmpty()? sDate.get(Calendar.HOUR_OF_DAY) : Integer.parseInt(newH);
			System.out.print("분(Min): ");
			String newMin = scan.nextLine();
			if((!newMin.isEmpty()) && (Integer.parseInt(newMin) < 1 || Integer.parseInt(newMin) > 59)) {
				throw new Exception("Wrong Minute");
			}
			int newMinute = newMin.isEmpty()? sDate.get(Calendar.MINUTE) : Integer.parseInt(newMin);
			
			newSDate = new GregorianCalendar(newYear, newMonth, newDate, newHour, newMinute);
		}catch(InputMismatchException e) {
			System.out.println("잘못된 형식의 입력입니다. 다시 입력하세요.");
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		try {
			System.out.println("마감 시간");
			System.out.print("연도(Year): ");
			String newY = scan.nextLine();
			if((!newY.isEmpty()) && (Integer.parseInt(newY) < 1)) { // 입력한 값이 음수일 경우 에러 발생
				throw new Exception("Wrong Year");
			}
			int newYear = newY.isEmpty()? dDate.get(Calendar.YEAR) : Integer.parseInt(newY);
			System.out.print("월(Month): ");
			String newM = scan.nextLine();
			if((!newM.isEmpty()) && (Integer.parseInt(newM) < 1 || Integer.parseInt(newM) > 12)) {
				throw new Exception("Wrong Month");
			}
			int newMonth= newM.isEmpty()? dDate.get(Calendar.MONTH) : Integer.parseInt(newM) - 1;
			System.out.print("일(Date): ");
			String newD = scan.nextLine();
			if((!newD.isEmpty()) && (Integer.parseInt(newD) < 1)) {
				throw new Exception("Wrong Date");
			}
			int newDate = newD.isEmpty()? dDate.get(Calendar.DATE) : Integer.parseInt(newD);
			System.out.print("시간(Hour): ");
			String newH = scan.nextLine();
			if((!newH.isEmpty()) && (Integer.parseInt(newH) < 1 || Integer.parseInt(newH) > 23)) {
				throw new Exception("Wrong Hour");
			}
			int newHour = newH.isEmpty()? dDate.get(Calendar.HOUR_OF_DAY) : Integer.parseInt(newH);
			System.out.print("분(Min): ");
			String newMin = scan.nextLine();
			if((!newMin.isEmpty()) && (Integer.parseInt(newMin) < 1 || Integer.parseInt(newMin) > 59)) {
				throw new Exception("Wrong Minute");
			}
			int newMinute = newMin.isEmpty()? dDate.get(Calendar.MINUTE) : Integer.parseInt(newMin);
			
			newDDate = new GregorianCalendar(newYear, newMonth, newDate, newHour, newMinute);
			
		}catch(InputMismatchException e) {
			System.out.println("잘못된 형식의 입력입니다. 다시 입력하세요.");
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		updateSchedule = new Schedule(newPriority, newCategory, newTitle, newNote, newSDate, newDDate);
		
		try{
			Schedule[] updateResult = manager.update(index, updateSchedule);
			Schedule original = updateResult[0];
			// 수정 전 내용 출력
			System.out.println("우선순위\t카테고리\t이름 및 내용\t\t시작 시간\t\t마감 시간");
			System.out.println("수정 전");
			if(original != null) {
				int priority = original.getPriority();
				char category = original.getCategory();
				String title = original.getTitle();
				String note = original.getNote();
				GregorianCalendar startDate = original.getStartDate();
				GregorianCalendar dueDate = original.getDueDate();
				
				System.out.print(priority + "\t" + category + "\t" + title + " - " + note);
				System.out.print("\t" + startDate.get(Calendar.YEAR) + '.' + (startDate.get(Calendar.MONTH) + 1) + '.' + startDate.get(Calendar.DATE) + ' ' + startDate.get(Calendar.HOUR_OF_DAY) + ':' + startDate.get(Calendar.MINUTE));
				System.out.println("\t" + dueDate.get(Calendar.YEAR) + '.' + (dueDate.get(Calendar.MONTH) + 1) + '.' + dueDate.get(Calendar.DATE) + ' ' + dueDate.get(Calendar.HOUR_OF_DAY) + ':' + dueDate.get(Calendar.MINUTE));
			}
			// 수정 후 내용 출력
			System.out.println("수정 후");
			int priority = updateSchedule.getPriority();
			char category = updateSchedule.getCategory();
			String title = updateSchedule.getTitle();
			String note = updateSchedule.getNote();
			GregorianCalendar startDate = updateSchedule.getStartDate();
			GregorianCalendar dueDate = updateSchedule.getDueDate();
			
			System.out.print(priority + "\t" + category + "\t" + title + " - " + note);
			System.out.print("\t" + startDate.get(Calendar.YEAR) + '.' + (startDate.get(Calendar.MONTH) + 1) + '.' + startDate.get(Calendar.DATE) + ' ' + startDate.get(Calendar.HOUR_OF_DAY) + ':' + startDate.get(Calendar.MINUTE));
			System.out.println("\t" + dueDate.get(Calendar.YEAR) + '.' + (dueDate.get(Calendar.MONTH) + 1) + '.' + dueDate.get(Calendar.DATE) + ' ' + dueDate.get(Calendar.HOUR_OF_DAY) + ':' + dueDate.get(Calendar.MINUTE));
			
		}catch(Exception e) {
			if(e.getMessage().equals("Out of Range")) {
				System.out.println("일정 목록이 가득 찼습니다. 완료된 일정 삭제 후 다시 시도하세요.");
			}
		}
	}
	
}// userInterface class 종료