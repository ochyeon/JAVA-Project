// 일정 매니저 class
import java.util.GregorianCalendar;
import java.io.*;

public class ScheduleManager{
	// date field
	private final int MAX_SCHEDULE_SIZE = 100; // 일정 최대 개수
	private Schedule[] scheduleList;
	private int scheduleNum; // 일정 개수
	
	
	// constructor
	ScheduleManager(){
		scheduleList = new Schedule[MAX_SCHEDULE_SIZE];
		scheduleNum = 0;
	}
	ScheduleManager(int i) {
		scheduleList = new Schedule[i];
		scheduleNum = 0;
	}
	
	// 파일에 저장
	public void writeSchedules(File file) throws IOException{
		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(new FileOutputStream(file));
			oos.writeInt(scheduleNum);
			for(int i = 0; i < scheduleNum; i++) {
				oos.writeObject(scheduleList[i]);
			}
		}finally {
			if(oos != null) {
				oos.close();	
			}
		}
	}
	// 파일에서 읽기
	public void readSchedules(File file) throws IOException, ClassNotFoundException{
		ObjectInputStream ois = null;
		try {
			ois = new ObjectInputStream(new FileInputStream(file));
			int count = ois.readInt(); // 저장된 일정 개수 read
			scheduleList = new Schedule[count * 2]; // 저장된 일정 개수의 두 배 크기의 배열 생성 (이후 일정 추가 등이 가능하도록)
			for(int i = 0; i < count; i++) {
				Schedule schedule = (Schedule) ois.readObject();
				scheduleList[i] = schedule;
			}
			scheduleNum = count;
		}finally {
			if(ois != null) {
				ois.close();	
			}
		}
	}
	
	// method
	// get 함수
	Schedule[] getScheduleList() { // 전체 일정 반환
		if(scheduleList == null || scheduleNum == 0) {
			return null;
		}
		Schedule allSchedule[] = new Schedule[scheduleNum];
		for(int i = 0; i < scheduleNum ; i++) {
			allSchedule[i] = scheduleList[i];
		}
		return allSchedule;
	}
	int getScheduleNum() {
		return scheduleNum;
	}
	void setScheduleNum() {
		scheduleNum++;
	}
	
	// 일정 추가 - 중복될 경우 예외 발생, 인터페이스에서 처리
	void addSchedule(Schedule s) throws Exception {
		// 일정 중복 검사 : 시작 날짜와 마감 날짜에 이미 일정이 존재할 경우 중복 처리 -> 사용자 확답 후 일정 추가(인터페이스)
		for(int i = 0; i < scheduleNum; i++) {
			if(s.equals(scheduleList[i])) {
				throw new Exception("Exist");
			}
		}
		// 중복 아닐 경우
		if (scheduleNum < scheduleList.length) { // 사용자가 입력한 스케쥴 리스트의 크기로 수정
			scheduleList[scheduleNum] = s;
			scheduleNum++;
		}
		else {
			throw new Exception("Out of Range");
		}
	}
	// 날짜가 중복되는 일정을 그냥 추가하는 경우
	void addSameSchedule(Schedule s) throws Exception {
		if(scheduleNum < scheduleList.length) {
			scheduleList[scheduleNum] = s;
			scheduleNum++;
		}
		else {
			throw new Exception("Out of Range");
		}
	}
	
	// 일정 검색(특정 날짜 이후 일정 검색)
	Schedule[] search(GregorianCalendar g) {
		Schedule searchList[] = new Schedule[scheduleNum]; // 검색된 일정만을 저장하는 리스트 생성
		int searchNum = 0; // 검색 일정 개수
		
		for(int i = 0; i < scheduleNum; i++) { // 일정 검색
			GregorianCalendar dueDate = scheduleList[i].getDueDate();
			if(dueDate.after(g)) {
				searchList[searchNum] = scheduleList[i];
				searchNum++;
			}
		}
		// 검색된 일정 없을 경우
		return searchNum > 0? searchList : null;
	}
	// 일정 검색(by 기간 사이)
	Schedule[] search(GregorianCalendar s, GregorianCalendar d) {
		Schedule searchList[] = new Schedule[scheduleNum]; // 검색된 일정만을 저장하는 리스트 생성
		int searchNum = 0; // 검색 일정 개수
		// s, d 반대로 입력된 경우
		if(s.after(d)) {
			GregorianCalendar t;
			t = s;
			s = d;
			d = t;
		}

		// s 부터 d 기간 사이에
		if (s.before(d) || s.equals(d)) {
			for (int i = 0; i < scheduleNum; i++) {
				GregorianCalendar startDate = scheduleList[i].getStartDate();
				GregorianCalendar dueDate = scheduleList[i].getDueDate();
				
				// 시작일 혹은 마감일이 기간 내 있을 경우
				if((startDate.equals(s) || startDate.after(s)) && (dueDate.equals(d) || dueDate.before(d))) {
					searchList[searchNum] = scheduleList[i];
					searchNum++;
				}
			}
		}
		// 검색된 일정이 없을 경우
		return searchNum > 0? searchList : null;
	}
	// 일정 검색(by 키워드)
	Schedule[] search(String keyword) {
		Schedule searchList[] = new Schedule[scheduleNum]; // 검색된 일정만을 저장하는 리스트 생성
		int searchNum = 0; // 검색 일정 개수
		
		for(int i = 0; i < scheduleNum; i++) {
			String title = scheduleList[i].getTitle();
			String note = scheduleList[i].getNote();
			
			if(title.contains(keyword) || note.contains(keyword)) {
				searchList[searchNum] = scheduleList[i];
				searchNum++;
			}
		}
		// 검색된 일정이 없을 경우
		return searchNum > 0? searchList : null;
	}
	// 일정 검색(by 우선순위 : 해당 우선순위의 일정들만 검색)
	Schedule[] search(int priority) {
		Schedule searchList[] = new Schedule[scheduleNum]; // 검색된 일정만을 저장하는 리스트 생성
		int searchNum = 0; // 검색 일정 개수
		
		for (int i = 0; i < scheduleNum ; i++) {
			int importance = scheduleList[i].getPriority();
			if(importance == priority) {
				searchList[searchNum] = scheduleList[i];
				searchNum++;
			}
		}
		// 검색된 일정이 없을 경우
		return searchNum > 0? searchList : null;
	}
	// 일정 검색(by 카테고리)
	Schedule[] search(char category) {
		Schedule searchList[] = new Schedule[scheduleNum]; // 검색된 일정만을 저장하는 리스트 생성
		int searchNum = 0; // 검색 일정 개수
		
		for (int i = 0; i < scheduleNum; i++) {
			char cat = scheduleList[i].getCategory();
			if(cat == category) {
				searchList[searchNum] = scheduleList[i];
				searchNum++;
			}
		}
		// 검색된 일정이 없을 경우
		return searchNum > 0? searchList : null;
	}
	
	// 일정 인덱스 반환(특정 날짜 검색)
	int[] searchIndex(GregorianCalendar g) {
		int indexList[] = new int[scheduleNum];
		int indexNum = 0;
		
		for(int i = 0; i < scheduleNum; i++) { // 일정 검색
			GregorianCalendar sDate = scheduleList[i].getStartDate();
			GregorianCalendar dDate = scheduleList[i].getDueDate();
			if(g.after(sDate) && g.before(dDate)) {
				indexList[indexNum++] = i;
			}
		}
		// 검색된 일정이 없을 경우
		if(indexNum == 0) {
			return new int[0];
		}
		int [] indexes = new int[indexNum];
		for(int i = 0; i < indexNum; i++) {
			indexes[i] = indexList[i];
		}

		return indexes;
	}
	// 일정 인덱스 반환(특정 기간 검색)
	int[] searchIndex(GregorianCalendar s, GregorianCalendar d) {
		int indexList[] = new int[scheduleNum];
		int indexNum = 0;

		// s, d 반대로 입력된 경우
		if(s.after(d)) {
			GregorianCalendar t;
			t = s;
			s = d;
			d = t;
		}

		// s 부터 d 기간 사이에
		for (int i = 0; i < scheduleNum; i++) {
			GregorianCalendar sDate = scheduleList[i].getStartDate();
			GregorianCalendar dDate = scheduleList[i].getDueDate();
			
			// 시작일 혹은 마감일이 기간 내 있을 경우
			if((sDate.equals(s) || (sDate.after(s) && sDate.before(d))) ||
				(dDate.equals(d) || (dDate.after(s) && dDate.before(d)))) {
				indexList[indexNum++] = i;
			}
		}
		// 검색된 일정이 없을 경우
		if(indexNum == 0) {
			return new int[0];
		}
		int [] indexes = new int[indexNum];
		for(int i = 0; i < indexNum; i++) {
			indexes[i] = indexList[i];
		}

		return indexes;
	}
	// 일정 인덱스 반환(특정 키워드 검색)
	int[] searchIndex(String keyword) {
		int indexList[] = new int[scheduleNum];
		int indexNum = 0;
		
		for(int i = 0; i < scheduleNum; i++) {
			String title = scheduleList[i].getTitle();
			String note = scheduleList[i].getNote();
			
			if(title.contains(keyword) || note.contains(keyword)) {
				indexList[indexNum++] = i;
			}
		}
		// 검색된 일정이 없을 경우
		if(indexNum == 0) {
			return new int[0];
		}
		int [] indexes = new int[indexNum];
		for(int i = 0; i < indexNum; i++) {
			indexes[i] = indexList[i];
		}

		return indexes;
	}
	// 일정 인덱스 반환(특정 우선순위 검색)
	int[] searchIndex(int priority) {
		int indexList[] = new int[scheduleNum];
		int indexNum = 0;
		
		for (int i = 0; i < scheduleNum ; i++) {
			int importance = scheduleList[i].getPriority();
			if(importance == priority) {
				indexList[indexNum++] = i;
			}
		}
		// 검색된 일정이 없을 경우
		if(indexNum == 0) {
			return new int[0];
		}
		int [] indexes = new int[indexNum];
		for(int i = 0; i < indexNum; i++) {
			indexes[i] = indexList[i];
		}

		return indexes;
	}
	// 일정 인덱스 반환(특정 카테고리 검색)
	int[] searchIndex(char category) {
		int indexList[] = new int[scheduleNum];
		int indexNum = 0;
		
		for (int i = 0; i < scheduleNum; i++) {
			char cat = scheduleList[i].getCategory();
			if(cat == category) {
				indexList[indexNum++] = i;
			}
		}
		// 검색된 일정이 없을 경우
		if(indexNum == 0) {
			return new int[0];
		}
		int [] indexes = new int[indexNum];
		for(int i = 0; i < indexNum; i++) {
			indexes[i] = indexList[i];
		}

		return indexes;
	}
	
	// 일정 삭제
	void deleteSchedule(int index) {
		for(int i = index; i < scheduleNum - 1 ; i++) {
			scheduleList[i] = scheduleList[i + 1];
		}
		scheduleList[scheduleNum - 1] = null; // 배열의 마지막 요소를 null 로 변경
		scheduleNum -= 1; // 배열의 마지막 요소를 무시함.
	}
	
	// 일정 수정
	Schedule[] update(int index, Schedule s){
		Schedule original = scheduleList[index];
		scheduleList[index] = s; // 선택한 인덱스의 일정을 s로 교체함
		
		Schedule[] updateResult = new Schedule[] {original, s}; // 선택한 기존 일정, 수정된 일정 저장 리스트
		return updateResult;
	}
}