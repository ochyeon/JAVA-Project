// 일정 class
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Schedule implements java.io.Serializable{
	// 직렬화 버전 관리 필드
	 private static final long serialVersionUID = 1L;
	// data field
	private GregorianCalendar startDate, dueDate;
	private String title, note;
	private char category; // 학교('U'niversity), 개인('P'ersonal), 가족('F'amily), 공부('S'tudy)
	private int priority; // 1 ~ 5 사이로 지정
	
	// constructor
	Schedule(int priority, char category, String title, String note, GregorianCalendar startDate, GregorianCalendar dueDate){
		this.startDate = startDate;
		this.dueDate = dueDate;
		this.category = category;
		this.title = title;
		this.note = note;
		this.priority = priority;
	}
	// method
	GregorianCalendar getStartDate() {
		return startDate;
	}
	GregorianCalendar getDueDate() {
		return dueDate;
	}
	char getCategory() {
		return category;
	}
	String getTitle() {
		return title;
	}
	String getNote() {
		return note;
	}
	int getPriority() {
		return priority;
	}
	
	void setTitle(String newTitle) {
		title = newTitle;
	}
	
	// 중복 일정 검사를 위한 equals 함수 재정의 (일정의 시작 날짜와 마감 날짜가 같으면 같은 일정으로 인식)
	public boolean equals(Object o) {
		GregorianCalendar checkSDate = new GregorianCalendar(startDate.get(Calendar.YEAR), startDate.get(Calendar.MONTH), startDate.get(Calendar.DATE));
		GregorianCalendar checkDDate = new GregorianCalendar(dueDate.get(Calendar.YEAR), dueDate.get(Calendar.MONTH), dueDate.get(Calendar.DATE));
		
		 if (this == o)
			 return true;
	     if (o == null || getClass() != o.getClass())
	    	 return false;
	     Schedule schedule = (Schedule) o;
	     GregorianCalendar ObjSDate = schedule.getStartDate();
	     GregorianCalendar ObjDDate = schedule.getDueDate();
	     GregorianCalendar checkObjSDate = new GregorianCalendar(ObjSDate.get(Calendar.YEAR), ObjSDate.get(Calendar.MONTH), ObjSDate.get(Calendar.DATE));
	     GregorianCalendar checkObjDDate = new GregorianCalendar(ObjDDate.get(Calendar.YEAR), ObjDDate.get(Calendar.MONTH), ObjDDate.get(Calendar.DATE));
	      
	     return checkSDate.equals(checkObjSDate) && checkDDate.equals(checkObjDDate);
	}
}